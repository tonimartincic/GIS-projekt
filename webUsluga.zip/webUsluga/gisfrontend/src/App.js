import './App.css';
import React, { Component, useRef, useEffect  } from 'react';
import ReactMapboxGl, { Layer, Feature, Source } from 'react-mapbox-gl';
import { GeoJSONLayer } from "react-mapbox-gl";
import DatePicker from "react-datepicker";
import "react-datepicker/dist/react-datepicker.css";
import hr from 'date-fns/locale/hr';
import { registerLocale, setDefaultLocale } from  "react-datepicker";
import "react-loader-spinner/dist/loader/css/react-spinner-loader.css"
import Loader from 'react-loader-spinner'
import { endOfToday, set } from 'date-fns' 
import TimeRange from 'react-timeline-range-slider' 
import { Button, Icon } from 'semantic-ui-react'
import 'semantic-ui-css/semantic.min.css';
registerLocale('hr', hr);



const Map = ReactMapboxGl({
  accessToken:
  'pk.eyJ1IjoiYXN0ZXJtaXgiLCJhIjoiY2pxMmRxc3R5MTNzaDQyb2J2bTExaWVucSJ9.JexCZBrcLkcoQE6lVkqzmg'

});

const sleep = (milliseconds) => {
  return new Promise(resolve => setTimeout(resolve, milliseconds))
}

let polygonPaint3 = ReactMapboxGl.FillPaint = {
  'fill-color': "#ff00ff",
  'fill-opacity': 0.5
}

let polygonPaint2 = ReactMapboxGl.FillPaint = {
  'fill-color': "#9966ff",
  'fill-opacity': 0.5
}

let polygonPaint1 = ReactMapboxGl.FillPaint = {
  'fill-color': "#3366ff",
  'fill-opacity': 0.5
}

let polygonPaint0 = ReactMapboxGl.FillPaint = {
  'fill-color': "#000099",
  'fill-opacity': 0.5
}

let predictedPolygonPaint = ReactMapboxGl.FillPaint = {
  'fill-color': "#339966",
  'fill-opacity': 0.5
}

const now = new Date()
const getTodayAtSpecificHour = (hour = 12) =>
	set(now, { hours: hour, minutes: 0, seconds: 0, milliseconds: 0 })

const selectedStart = getTodayAtSpecificHour(0)
const selectedEnd = getTodayAtSpecificHour(24)

const startTime = getTodayAtSpecificHour(0)
const endTime = getTodayAtSpecificHour(24)

const disabledIntervals = [
  
]



class App extends Component{
  
  

  constructor(props) {
    
    super(props);

    this.state={
      polygons : [],
      geojsonobjects: [],
      selectedDate: "",
      loader: false,
      error:false,
      selectedInterval: [selectedStart, selectedEnd],  
      playDisabled : true,
      animationPlayed: false,
      selectedHour: "00",
      selectedMinute: "00",
      centerCoordinates: [15,45],
      zoom: [6]
    };
      
  };

  handleChange = name => event => {
    this.setState({
      [name]: event.target.value,
    });
  };

  errorHandler = ({ error }) => this.setState({ error })  

  onChangeCallback = selectedInterval => {
    this.setState({ selectedInterval })
    this.parseVisibleRange(selectedInterval)
  }  

  parseDate(javaDate){
    var timestamp = javaDate.split("T")
    var date = timestamp[0].split("-")
    var year = date[0]
    var month = date[1]
    var day = date[2]
    var time = timestamp[1].split(":")
    var hours = time[0]
    var minutes = time[1]
    var d = new Date(year, month-1, day, hours, minutes, 0, 0)
    d.setHours(d.getHours()+2);
    return d
  }


    async getData(date){

      var objects = []
     
      const options={
          method:'POST',
          headers: {
            'Accept': 'application/json',
            'Content-Type': 'application/json',
        },
          
      };
      this.setState({loader:true})
      await fetch('/polygons/loadData/'+date,options)
     
      const options2={
        method:'GET',
        headers: {
            'Accept': 'application/json',
            'Content-Type': 'application/json',
        },
      };
      var counter = 0
      await fetch('/polygons', options2)
      .then(data=>data.json())
      .then(polygons=>{
        
        for(var i=0; i<polygons.length; ++i){
          var poly = polygons[i]
          poly.timestamp = this.parseDate(poly.timestamp)
          var points = poly.points
          var centroid = [0,0]
          for(var j=0; j<points.length; ++j){
            centroid[1] += points[j].latitude
            centroid[0] += points[j].longitude
          }
          centroid[0] = centroid[0]/points.length
          centroid[1] = centroid[1]/points.length
          poly.centroid = centroid
          
        }
        
        this.setState({polygons : polygons})
        for(var i=0; i<polygons.length; ++i){
          var polygon = polygons[i]
          var points = polygon.points
          var coordinates = []
          for(var j=0; j<points.length; ++j){
            var point = points[j]
            var coord = [point.longitude, point.latitude]
            coordinates.push(coord)
          }
          let object = { 
            paintId: polygon.timeId,    
            id: counter,
            type: "FeatureCollection",
            features: [{
               "type": "Feature",
                
                "geometry": {
                      "type": "Polygon",
                       "coordinates": [coordinates]
                 }
            }]
          }
          
          objects.push(object)
          counter += 1
        }
      })
      this.setState({geojsonobjects: objects})
      this.setState({loader:false})
      this.setState({playDisabled: false})
      
      
    }

    parseVisibleRange(selectedInterval){
      this.setState({loader:true})
      var newPolygons = []
      for(var i=0; i<this.state.polygons.length; ++i){
        var polygon = this.state.polygons[i]
        var timestamp = polygon.timestamp
        var year = timestamp.getFullYear()
        var month = timestamp.getMonth()
        var day = timestamp.getDate()
        var start = new Date(year, month, day, selectedInterval[0].getHours(), selectedInterval[0].getMinutes(), 0, 0)
        var end = new Date(year, month, day, selectedInterval[1].getHours(), selectedInterval[1].getMinutes(), 0, 0)

        if(start <= timestamp && end >= timestamp){
          newPolygons.push(polygon)
          
        }
   
      }

      var objects = []
      var counter = 0
      for(var i=0; i<newPolygons.length; ++i){
        var polygon = newPolygons[i]
        var points = polygon.points
        var coordinates = []
        for(var j=0; j<points.length; ++j){
          var point = points[j]
          var coord = [point.longitude, point.latitude]
          coordinates.push(coord)
        }
        let object = {
          paintId: polygon.timeId,  
          id: counter,
          type: "FeatureCollection",
          features: [{
             "type": "Feature",
              
              "geometry": {
                    "type": "Polygon",
                     "coordinates": [coordinates]
               }
          }]
          }
          objects.push(object)
          counter += 1
        }

          this.setState({geojsonobjects: objects})
          this.setState({loader:false})

    }

    parseVisible(d){
      
      this.setState({loader:true})
      var newPolygons = []
      for(var i=0; i<this.state.polygons.length; ++i){
        var polygon = this.state.polygons[i]
        var timestamp = polygon.timestamp
        var year = timestamp.getFullYear()
        var month = timestamp.getMonth()
        var day = timestamp.getDate()
        var current = new Date(year, month, day, d.getHours(), d.getMinutes(), 0, 0)
        
        if(current.toUTCString() === timestamp.toUTCString()){
          newPolygons.push(polygon)
          this.setState({centerCoordinates: polygon.centroid})
          this.setState({zoom: [9]})
        }
      }

      var objects = []
      var counter = 0
      for(var i=0; i<newPolygons.length; ++i){
        var polygon = newPolygons[i]
        var points = polygon.points
        var coordinates = []
        for(var j=0; j<points.length; ++j){
          var point = points[j]
          var coord = [point.longitude, point.latitude]
          coordinates.push(coord)
        }
        let object = {  
          paintId: polygon.timeId,  
          id: counter,
          type: "FeatureCollection",
          features: [{
             "type": "Feature",
              
              "geometry": {
                    "type": "Polygon",
                     "coordinates": [coordinates]
               }
          }]
          }
          objects.push(object)
          counter += 1
        }

          this.setState({geojsonobjects: objects})
          this.setState({loader:false})
  

    }
    parseHour(time){
      if(time === 0){
        return"00"
      }
      else if(time < 10){
        return "0"+time
      }
      else{
        return time
      }
     
    }

    parseMinute(time){
      if(time == 0){
       return "00"
      }
      else{
        return time
      }

    }

    

    handleDateChange=(date)=>{
      this.setState({selectedInterval: [selectedStart, selectedEnd]})
      this.setState({selectedHour: "00"})
      this.setState({selectedMinute: "00"})
      this.setState({zoom:[6] })
      this.setState({centerCoordinates:  [15,45]})
      date.setHours(date.getHours() + 1);
      var parsedDate = date.toISOString().split("T")[0];      
      this.getData(parsedDate)
      this.setState({selectedDate: date})
      
    }

    playAnimation=()=>{
      this.setState({animationPlayed: true})
      this.setState({zoom:[6] })
      this.setState({centerCoordinates:  [15,45]})
      var startHour = this.state.selectedInterval[0].getHours()
      var startMinute = this.state.selectedInterval[0].getMinutes()
      var endHour = this.state.selectedInterval[1].getHours()
      var endMinute = this.state.selectedInterval[1].getMinutes()
      
      this.setTime(startHour, startMinute, endHour, endMinute)
      
    }

    pauseAnimation=()=>{
      this.setState({animationPlayed: false})

    }

    async setTime(startHour, startMinute, endHour, endMinute){
      var start = [startHour, startMinute]
      var end = [endHour, endMinute]
      var current = [startHour, startMinute]

      var date = new Date();
      date.setHours(start[0])
      date.setMinutes(start[1])
      date.setSeconds(0)
      this.setState({selectedHour: this.parseHour(start[0]) })
      this.setState({selectedMinute: this.parseMinute(start[1]) })
      this.parseVisible(date)
      await sleep(3000)

      while(current[0] != end[0] || current[1]!=end[1]){
        current[1]+=10
        if(current[1]==60){
          current[0]+=1
          current[1]=0
        }
        var date = new Date();
        date.setHours(current[0])
        date.setMinutes(current[1])
        date.setSeconds(0)
        this.setState({selectedHour: this.parseHour( current[0]) })
        this.setState({selectedMinute: this.parseMinute(current[1]) })
        this.parseVisible(date)
        await sleep(3000)
        if(!this.state.animationPlayed){
          break
        }

      }
      this.setState({animationPlayed: false})

    }

    parseFetchResponse = response => response.json().then(text => ({
      json: text,
      meta: response,
    }));

    getPaint(object){
      if(object.paintId == -3){
        return polygonPaint3
      }
      else if(object.paintId == -2){
        return polygonPaint2
      }
      else if(object.paintId == -1){
        return polygonPaint1
      }
      else if(object.paintId == 0){
        return polygonPaint0
      }
      else if(object.paintId == 1){
        return predictedPolygonPaint
      }

    }



    render(){
      const { selectedInterval, error } = this.state 
        return (

          <div>

            <div style={{ marginTop:4+'vh', marginLeft:4+'vh'}}>
            <h3>{"Odaberite datum i vremenski raspon"}</h3>
            <DatePicker
              selected={this.state.selectedDate}
              onChange={this.handleDateChange} 
              locale="hr"
              dateFormat="yyyy-MM-dd"
              showYearDropdown
              showMonthDropdown
            />

            <div style={{  marginLeft:37+'vh', display:"flex", flexDirection:"row"}}>
              {!this.state.animationPlayed ? 
              <Button icon labelPosition='right' color='green' size="big" onClick={this.playAnimation} disabled={this.state.playDisabled}>
              Play
              <Icon name='play' />
              </Button>
              : 
              <Button icon labelPosition='right' color='red' size="big" onClick={this.pauseAnimation} >
              Pause
              <Icon name='pause' />
              </Button>}
            <h4>&nbsp;&nbsp;&nbsp;Time= {this.state.selectedHour}:{this.state.selectedMinute}</h4>
            </div>

            <div style={{ marginTop:4+'vh', marginLeft:18+'vh'}}>
             <TimeRange

              error={error}  
              ticksNumber={36}  
              selectedInterval={selectedInterval}  
              timelineInterval={[startTime, endTime]}  
              onUpdateCallback={this.errorHandler}  
              onChangeCallback={this.onChangeCallback}
              disabledIntervals={disabledIntervals}  
            />
            </div>

            </div>
            

            <div style={{ marginTop:4+'vh', marginLeft:4+'vh'}}>
            <center>
            <br></br>
            <Loader
              type="ThreeDots"
              color="#FF9700"
              height={300}
              width={300}
              visible={this.state.loader}
            />
            </center>
            {!this.state.loader ?
            <div>
              
            <Map
            
              style="mapbox://styles/mapbox/light-v9"
              containerStyle={{
                height: '75vh',
                width: '75vw'
              }}
              center= {this.state.centerCoordinates}
              zoom = {this.state.zoom}
            >

            {this.state.geojsonobjects.map(object => 

              <GeoJSONLayer
              key={object.id}
              data={object}
              fillPaint={this.getPaint(object)}
              />
            )} 

            </Map>


          </div>
          
          :
          <div></div>
            
            
            }
            
            </div>
          <br></br><br></br><br></br>
          </div>
          
          
            
          
          ); 
    }
  }


export default App;

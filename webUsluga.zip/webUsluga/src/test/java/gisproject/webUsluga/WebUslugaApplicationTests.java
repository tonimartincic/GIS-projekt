package gisproject.webUsluga;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class WebUslugaApplicationTests {

	@Test
	void contextLoads() {
	}

}

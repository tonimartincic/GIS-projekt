package gisproject.webUsluga.service.impl;

import java.io.File;
import java.io.FileNotFoundException;
import java.sql.Date;
import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Scanner;
import java.util.Set;

import javax.annotation.Resource;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;
import org.springframework.util.Assert;

import gisproject.webUsluga.dao.PointRepository;
import gisproject.webUsluga.dao.PolygonRepository;
import gisproject.webUsluga.domain.Point;
import gisproject.webUsluga.domain.Polygon;
import gisproject.webUsluga.service.PolygonService;

@Service
public class PolygonServiceJpa implements PolygonService{
	
	@Autowired
	private PolygonRepository polygonRepo;
	
	@Autowired
	private PointRepository pointRepo;
	
	@Override
	public List<Polygon> listAll(){
		return polygonRepo.findAll();
	}

	@Override
	public Polygon createPolygon(Polygon polygon) {
		Assert.notNull(polygon, "Polygon object must be given!");
		Assert.isNull(polygon.getId(), "Polygon ID must be null!");
		return polygonRepo.save(polygon);
	}

	@SuppressWarnings({ "deprecation", "deprecation" })
	@Override
	public Set<Polygon> loadPolygons(String selectedDate) {
		polygonRepo.deleteAll();
		pointRepo.deleteAll();
		String path = "../Data/cluster.csv";
		int counter = 0;
		boolean flag = false;
		ArrayList<Polygon> polygons = new ArrayList<Polygon>();
		try {
			Scanner scanner = new Scanner(new File(path) );
			while (scanner.hasNextLine()  ) {
				String line = scanner.nextLine();
				if(flag == true) {
					
					String[] parts = line.split("POLYGON");
					String[] datePart = parts[0].split(",");
					String[] datePart2 = datePart[0].split(" ");
					if(datePart2[0].equals(selectedDate)) {
						String[] date = datePart2[0].split("-");
						String[] time = datePart2[1].split(":");
						Timestamp ts = Timestamp.valueOf(String.format("%04d-%02d-%02d %02d:%02d:%02d", Integer.parseInt(date[0]), Integer.parseInt(date[1]), Integer.parseInt(date[2]),Integer.parseInt(time[0]), Integer.parseInt(time[1]), Integer.parseInt(time[2])));
						String[] parts2 = parts[1].split("\\)");
						String[] pointList = parts2[0].substring(3, parts2[0].length()).split(", ");
						ArrayList<Point> points = new ArrayList<Point>();
						for(String p : pointList) {
							String[] coordinates = p.split(" ");
							Point point = new Point(Double.parseDouble(coordinates[1]), Double.parseDouble(coordinates[0]));
							points.add(point);
							pointRepo.save(point);
						}
						
						Polygon pol = new Polygon(ts, points,0);
						polygons.add(pol);
						polygonRepo.save(pol);						
						
					}
									
					counter ++;
					
				}else {
					flag = true;
				}
			}
			scanner.close();
		} catch (FileNotFoundException e) {
			e.printStackTrace();
		}
		return null;
	}

	
	@Override
	public Set<Polygon> loadTrainPolygons(String selectedDate) {
		polygonRepo.deleteAll();
		pointRepo.deleteAll();
		String dataPath = "../Data/podaci-za-ucenje.csv";
		String predictionPath = "../Data/prediction.csv";
		
		ArrayList<ArrayList<Double>> predictions = new ArrayList<ArrayList<Double>>();
		try {
			Scanner scannerPred = new Scanner(new File(predictionPath) );
			while (scannerPred.hasNextLine()  ) {
				String line = scannerPred.nextLine();
				String[] parts = line.split(",");
				double lat = Double.parseDouble(parts[1]);
				double lon = Double.parseDouble(parts[0]);
				ArrayList<Double> coord = new ArrayList<Double>();
				coord.add(lat);
				coord.add(lon);
				predictions.add(coord);	
			}
			scannerPred.close();
		} catch (FileNotFoundException e) {
			e.printStackTrace();
		}
		
		int counter = -1;
		boolean flag = false;
		ArrayList<Polygon> polygons = new ArrayList<Polygon>();
		
		ArrayList<Point> predPoints = new ArrayList<Point>();
		try {
			Scanner scanner = new Scanner(new File(dataPath) );
			while (scanner.hasNextLine()  ) {
				String line = scanner.nextLine();
				if(flag == true) {	
					String[] parts = line.split("\"");
					String[] timeParts = parts[2].split(",");
					String timeString = timeParts[3];
					String[] dateParts = timeString.split("T");
					String[] dateParts2 = dateParts[0].split("-");
					String[] dateParts3 = dateParts[1].split(":");
					String year = dateParts2[0];
					String month = dateParts2[1];
					String day = dateParts2[2];
					String hour = dateParts3[0];
					String minute = dateParts3[1];
					counter++;
					Polygon predictionPolygon;
					if(dateParts[0].equals(selectedDate)) {
						ArrayList<Double> predictionCentroid = predictions.get(counter/4);
						String[] allParts = line.split(",");
						Integer timeId = Integer.parseInt(allParts[2]);
				
						Timestamp ts = Timestamp.valueOf(String.format("%04d-%02d-%02d %02d:%02d:%02d", Integer.parseInt(year), Integer.parseInt(month), Integer.parseInt(day),Integer.parseInt(hour), Integer.parseInt(minute), 0));
						ArrayList<Point> points = new ArrayList<Point>();
						String[] pointList = parts[1].substring(9, parts[1].length()-2).split(",");
						for(String p : pointList) {
							String[] coordinates = p.split(" ");
							Point point = new Point(Double.parseDouble(coordinates[1]), Double.parseDouble(coordinates[0]));
							points.add(point);
							pointRepo.save(point);
						}
						Polygon pol = new Polygon(ts, points, timeId);
						polygons.add(pol);
						polygonRepo.save(pol);
						
						
						if(timeId == -1) {
							Double centroidLat = Double.parseDouble(allParts[5]);
							Double centroidLon = Double.parseDouble(allParts[4]);
							Double diffLat = predictionCentroid.get(0) - centroidLat;
							Double diffLon = predictionCentroid.get(1) - centroidLon;
							predPoints = new ArrayList<Point>();
							for(Point p : points) {
								Double predLat = p.getLatitude() + diffLat;
								Double predLon = p.getLongitude() + diffLon;
								Point predPoint = new Point(predLat, predLon);
								predPoints.add(predPoint);
								pointRepo.save(predPoint);
							}
							
							
						}
						
						if(timeId == 0) {
							Polygon predPolygon = new Polygon(ts, predPoints, 1);
							polygons.add(predPolygon);
							polygonRepo.save(predPolygon);
							
						}
					}
					
					
				}else {
					flag = true;
				}
			}
			scanner.close();
		} catch (FileNotFoundException e) {
			e.printStackTrace();
		}
		
	
		return null;
	}

}

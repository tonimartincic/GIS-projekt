package gisproject.webUsluga.service;
import java.util.List;
import gisproject.webUsluga.domain.Point;

public interface PointService {
	List<Point> listAll();
	
	Point createPoint(Point point);

}

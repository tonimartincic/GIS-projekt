package gisproject.webUsluga.service.impl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.util.Assert;

import gisproject.webUsluga.dao.PointRepository;
import gisproject.webUsluga.domain.Point;
import gisproject.webUsluga.service.PointService;

@Service
public class PointServiceJpa implements PointService{
	
	@Autowired
	private PointRepository pointRepo;
	
	@Override
	public List<Point> listAll(){
		return pointRepo.findAll();
	}

	@Override
	public Point createPoint(Point point) {
		Assert.notNull(point, "Point object must be given!");
		Assert.isNull(point.getId(), "Point ID must be null!");
		return pointRepo.save(point);
	}

}

package gisproject.webUsluga.service;
import java.util.List;
import java.util.Set;

import gisproject.webUsluga.domain.Point;
import gisproject.webUsluga.domain.Polygon;

public interface PolygonService {
	List<Polygon> listAll();
	
	Polygon createPolygon(Polygon polygon);
	
	Set<Polygon> loadPolygons(String selectedDate);
	
	Set<Polygon> loadTrainPolygons(String selectedDate);

}

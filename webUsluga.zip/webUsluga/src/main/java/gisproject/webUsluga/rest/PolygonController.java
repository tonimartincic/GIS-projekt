package gisproject.webUsluga.rest;

import java.util.List;
import java.util.Set;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import gisproject.webUsluga.domain.Point;
import gisproject.webUsluga.domain.Polygon;
import gisproject.webUsluga.service.PointService;
import gisproject.webUsluga.service.PolygonService;

@RestController
@RequestMapping("/polygons")
public class PolygonController {
	
	@Autowired
	private PolygonService polygonService;
	
	@Autowired
	private PointService pointService;
	
	@GetMapping("")
	public List<Polygon> listPolygons(){
		return polygonService.listAll();
	}
	
	@PostMapping("")
	public Polygon createPolygon(@RequestBody Polygon polygon){
		return polygonService.createPolygon(polygon);
	}
	
	@PostMapping("/load/{selectedDate}")
	public Set<Polygon> loadPolygons(@PathVariable("selectedDate") final String selectedDate){
		return polygonService.loadPolygons(selectedDate);
	}
	
	@PostMapping("/loadData/{selectedDate}")
	public Set<Polygon> loadTrainPolygons(@PathVariable("selectedDate") final String selectedDate){
		return polygonService.loadTrainPolygons(selectedDate);
	}
}

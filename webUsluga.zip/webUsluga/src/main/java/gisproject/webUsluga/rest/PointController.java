package gisproject.webUsluga.rest;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import gisproject.webUsluga.domain.Point;
import gisproject.webUsluga.service.PointService;

@RestController
@RequestMapping("/points")
public class PointController {
	
	@Autowired
	private PointService pointService;
	
	@GetMapping("")
	public List<Point> listPoints(){
		return pointService.listAll();
	}
	
	@PostMapping("")
	public Point createPoint(@RequestBody Point point){
		return pointService.createPoint(point);
	}
}

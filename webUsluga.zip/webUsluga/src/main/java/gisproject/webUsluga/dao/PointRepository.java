package gisproject.webUsluga.dao;

import org.springframework.data.jpa.repository.JpaRepository;

import gisproject.webUsluga.domain.Point;

public interface PointRepository extends JpaRepository<Point, Long> {

}

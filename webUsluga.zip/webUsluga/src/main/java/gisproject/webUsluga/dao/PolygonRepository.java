package gisproject.webUsluga.dao;

import org.springframework.data.jpa.repository.JpaRepository;

import gisproject.webUsluga.domain.Point;
import gisproject.webUsluga.domain.Polygon;

public interface PolygonRepository extends JpaRepository<Polygon, Long> {

}

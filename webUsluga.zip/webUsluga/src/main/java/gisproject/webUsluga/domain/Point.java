package gisproject.webUsluga.domain;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;

@Entity
public class Point {

	@Id
	@GeneratedValue
	private Long id;
	
	private double latitude;
	private double longitude;
	public Long getId() {
		return id;
	}
	public void setId(Long id) {
		this.id = id;
	}
	public double getLatitude() {
		return latitude;
	}
	public void setLatitude(double latitude) {
		this.latitude = latitude;
	}
	public double getLongitude() {
		return longitude;
	}
	public void setLongitude(double longitude) {
		this.longitude = longitude;
	}
	public Point(double latitude, double longitude) {
		super();
		this.latitude = latitude;
		this.longitude = longitude;
	}
	@Override
	public String toString() {
		return "POINT : ("+this.latitude+", "+this.longitude+")";
	}
	public Point() {
		super();
	}
	
	
	
	
	
}

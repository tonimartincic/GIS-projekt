package gisproject.webUsluga.domain;

import java.sql.Date;
import java.sql.Timestamp;
import java.util.List;
import java.util.Set;

import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.JoinTable;
import javax.persistence.OneToMany;
import javax.persistence.JoinColumn;

@Entity
public class Polygon {
	
	@Id
	@GeneratedValue
	private Long id;
	
	private Timestamp timestamp;
	
	
	private int timeId;
	
	@OneToMany(fetch = FetchType.LAZY)
    @JoinTable(name = "polygon_points",
            joinColumns = @JoinColumn(name = "polygon_id"),
            inverseJoinColumns = @JoinColumn(name = "point_id"))
	private List<Point> points;

	public Long getId() {
		return id;
	}

	

	public int getTimeId() {
		return timeId;
	}



	public void setTimeId(int timeId) {
		this.timeId = timeId;
	}



	public void setId(Long id) {
		this.id = id;
	}

	public List<Point> getPoints() {
		return points;
	}

	public void setPoints(List<Point> points) {
		this.points = points;
	}


	public Timestamp getTimestamp() {
		return timestamp;
	}

	public void setTimestamp(Timestamp timestamp) {
		this.timestamp = timestamp;
	}
	
	

	public Polygon() {
		super();
	}
	
	

	public Polygon(Timestamp timestamp, List<Point> points, int timeId) {
		super();
		this.timestamp = timestamp;
		this.points = points;
		this.timeId =  timeId;
	}

	@Override
	public String toString() {
		String s = "Polygon with timeId ["+ this.timeId+ "] in time "+this.timestamp+" with points [ ";
		for(Point p : this.points) {
			s+="( "+p.toString()+" );";
		}
		s+=" ]";
		return s;
	}
	
}
